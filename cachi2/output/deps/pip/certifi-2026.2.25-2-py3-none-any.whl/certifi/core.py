# RHEL system store
def where() -> str:
    return "/etc/pki/tls/certs/ca-bundle.crt"

def contents() -> str:
    with open(where(), encoding="utf=8") as f:
        return f.read()
